package main

import (
	"fmt"
	"log"
	"net/http"
	"strconv"
)

// Una funfion handler para devolver un texto
func home(w http.ResponseWriter, r *http.Request) {

	//Esto es para evitar que el path "/" realice el catch-all
	//Si no encuentra path "/" lo envia a not found
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}

	w.Write([]byte("Hello world"))
}

// Add a snippetView handler
func snippetView(w http.ResponseWriter, r *http.Request) {
	//Al consultar por un indice neceitamos pasar de string a intenger con strconv.Atoi
	//r.URL.Query().Get() para capturar la query
	id, err := strconv.Atoi(r.URL.Query().Get("id"))
	if err != nil || id < 1 {
		http.NotFound(w, r)
		return
	}
	id = id + 10
	fmt.Fprintf(w, "Display a specific snippet with ID %d...\n", id)
	w.Write([]byte("Display a specific snippet ...."))
}

// Add a snippetCreate handler
func snippetCreate(w http.ResponseWriter, r *http.Request) {

	if r.Method != "POST" {
		//Verifica si el metodo es un POST, solo permirte POST
		//w.Header().Set("Allow", "POST")
		w.Header().Set("Allow", http.MethodPost)
		//w.Header().Set("HOLA", "ALGO")
		//w.WriteHeader(405)
		w.Header().Set("Content-Type", "application/json")
		// http.MethodPost y http.StatusMethodNotAllowed son constantes de POST y 405
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		//w.Write([]byte("Method Not Allowed"))
		return
	}
	w.Write([]byte("Create a new snippet ...."))
}

// Add a snippetCreate handler
func snippetList(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Write([]byte(`{"status":"succes"}`))
}

func main() {
	//Usamos http.NewServeMux() para inicializar a new servemux(router)
	mux := http.NewServeMux()
	//Enrutamos la ruta al HandleFunc llamado home
	mux.HandleFunc("/", home)
	mux.HandleFunc("/snippet/view", snippetView)
	mux.HandleFunc("/snippet/create", snippetCreate)
	mux.HandleFunc("/list.snippet.org", snippetList)

	log.Print("Starting server on :8080")
	//Inicializa el servidor mux en el puerto 8080
	err := http.ListenAndServe("0.0.0.0:8080", mux)
	log.Fatal(err)

}
